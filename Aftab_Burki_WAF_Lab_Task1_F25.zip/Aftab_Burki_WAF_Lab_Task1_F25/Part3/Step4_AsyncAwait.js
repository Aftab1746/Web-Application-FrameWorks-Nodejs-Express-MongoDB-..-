function delay(fn, time) {
  return new Promise(resolve => {
    setTimeout(() => {
      fn();
      resolve();
    }, time);
  });
}

async function executeTasks() {
  await delay(() => console.log("Register completed"), 2500);
  await delay(() => console.log("Welcome message sent"), 3000);
  await delay(() => console.log("Login completed"), 2000);
  await delay(() => console.log("Profile fetched"), 4000);
  await delay(() => console.log("Status updated"), 1500);
  await delay(() => console.log("Logout completed"), 3500);
  console.log("All operations finished (Async/Await version)");
}

executeTasks();
