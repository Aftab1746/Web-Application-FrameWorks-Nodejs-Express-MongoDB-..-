// console.log("\n ................ NORMAL EXECUTION ..............");

// function register() {
//   setTimeout(() => console.log("Register completed"), 2500);
// }

// function sendWelcomeMessage() {
//   setTimeout(() => console.log("Welcome message sent"), 3000);
// }

// function login() {
//   setTimeout(() => console.log("Login completed"), 2000);
// }

// function fetchProfile() {
//   setTimeout(() => console.log("Profile fetched"), 4000);
// }

// function updateStatus() {
//   setTimeout(() => console.log("Status updated"), 1500);
// }

// function logout() {
//   setTimeout(() => console.log("Logout completed"), 3500);
// }

// register();
// sendWelcomeMessage();
// login();
// fetchProfile();
// updateStatus();
// logout();

// console.log("All operations finished (Normal Async)\n");

// console.log("................ CALLBACK VERSION .................");

// function registerCb(callback) {
//   setTimeout(() => {
//     console.log("Register completed");
//     callback();
//   }, 2500);
// }

// function sendWelcomeMessageCb(callback) {
//   setTimeout(() => {
//     console.log("Welcome message sent");
//     callback();
//   }, 3000);
// }

// function loginCb(callback) {
//   setTimeout(() => {
//     console.log("Login completed");
//     callback();
//   }, 2000);
// }

// function fetchProfileCb(callback) {
//   setTimeout(() => {
//     console.log("Profile fetched");
//     callback();
//   }, 4000);
// }

// function updateStatusCb(callback) {
//   setTimeout(() => {
//     console.log("Status updated");
//     callback();
//   }, 1500);
// }

// function logoutCb(callback) {
//   setTimeout(() => {
//     console.log("Logout completed");
//     callback();
//   }, 3500);
// }

// registerCb(() => {
//   sendWelcomeMessageCb(() => {
//     loginCb(() => {
//       fetchProfileCb(() => {
//         updateStatusCb(() => {
//           logoutCb(() => {
//             console.log("All operations finished (Callback version)\n");
//           });
//         });
//       });
//     });
//   });
// });

// console.log("................... PROMISE VERSION .................");

// function registerP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Register completed");
//       resolve();
//     }, 2500)
//   );
// }

// function sendWelcomeMessageP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Welcome message sent");
//       resolve();
//     }, 3000)
//   );
// }

// function loginP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Login completed");
//       resolve();
//     }, 2000)
//   );
// }

// function fetchProfileP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Profile fetched");
//       resolve();
//     }, 4000)
//   );
// }

// function updateStatusP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Status updated");
//       resolve();
//     }, 1500)
//   );
// }

// function logoutP() {
//   return new Promise(resolve =>
//     setTimeout(() => {
//       console.log("Logout completed");
//       resolve();
//     }, 3500)
//   );
// }

// registerP()
//   .then(sendWelcomeMessageP)
//   .then(loginP)
//   .then(fetchProfileP)
//   .then(updateStatusP)
//   .then(logoutP)
//   .then(() => console.log("All operations finished (Promise version)\n"));

// console.log(" ..................... ASYNC/AWAIT VERSION ................");

// function delay(fn, time) {
//   return new Promise(resolve => {
//     setTimeout(() => {
//       fn();
//       resolve();
//     }, time);
//   });
// }

// async function executeTasks() {
//   await delay(() => console.log("Register completed"), 2500);
//   await delay(() => console.log("Welcome message sent"), 3000);
//   await delay(() => console.log("Login completed"), 2000);
//   await delay(() => console.log("Profile fetched"), 4000);
//   await delay(() => console.log("Status updated"), 1500);
//   await delay(() => console.log("Logout completed"), 3500);
//   console.log("All operations finished (Async/Await version)\n");
// }

// executeTasks();




function register() {
  setTimeout(() => {
    console.log("Register completed");
  }, 2500);
}

function sendWelcomeMessage() {
  setTimeout(() => {
    console.log(" Welcome message sent");
  }, 3000);
}

function login() {
  setTimeout(() => {
    console.log(" Login completed");
  }, 2000);
}

function fetchProfile() {
  setTimeout(() => {
    console.log(" Profile fetched");
  }, 4000);
}

function updateStatus() {
  setTimeout(() => {
    console.log(" Status updated");
  }, 1500);
}

function logout() {
  setTimeout(() => {
    console.log(" Logout completed");
  }, 3500);
}

register();
sendWelcomeMessage();
login();
fetchProfile();
updateStatus();
logout();

console.log("All operations finished!");


