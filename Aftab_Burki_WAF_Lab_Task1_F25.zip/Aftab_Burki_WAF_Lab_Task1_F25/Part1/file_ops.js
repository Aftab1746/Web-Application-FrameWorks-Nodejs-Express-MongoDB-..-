// Import fs and path Modules
const fs = require('fs');
const path = require('path');


const folderPath = path.join(__dirname, 'storage');
const filePath = path.join(folderPath,"info.txt")

//Step 3: Create Storage Folder in the Same Foldr Where file_ops.js exist
if (!fs.existsSync(folderPath)) {
  fs.mkdirSync(folderPath);
  console.log('Folder "storage" created successfully!');
} else {
  console.log('Folder "storage" already exists.');
}

// Step 4:Create a file info.txt inside storage folder
fs.writeFileSync(filePath, "")

// Step 5: Append full Name in info.txt file
fs.appendFileSync(filePath, "Aftab Burki")

//Step 6: Read full Name from info.txt file and Display it on console
const data1 = fs.readFileSync(filePath, "utf8")
console.log(data1)

//Step 7: Overwrite the Fist Name A and Last Name B in info.txt
fs.writeFileSync(filePath, "AB")

//Step 8: Repeat Step 6 , Display data on console
const data2 = fs.readFileSync(filePath, "utf8")
console.log(data2)

//Step 9: Clear all data from info.txt
fs.writeFileSync(filePath, "");

//Step 10: Repear step 5 to write your full Name
fs.writeFileSync(filePath, "Aftab Burki");