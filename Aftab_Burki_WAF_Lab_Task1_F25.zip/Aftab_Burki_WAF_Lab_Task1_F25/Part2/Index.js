const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, 'MOCK_DATA.json');
const rawData = fs.readFileSync(dataPath, 'utf8');
const records = JSON.parse(rawData);

const files = ['com.txt', 'org.txt', 'edu.txt', 'uk.txt'];
files.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, '');
  }
});

records.forEach(record => {
  const email = record.email.toLowerCase();
  let targetFile = null;

  if (email.endsWith('.com')) targetFile = 'com.txt';
  else if (email.endsWith('.org')) targetFile = 'org.txt';
  else if (email.endsWith('.edu')) targetFile = 'edu.txt';
  else if (email.endsWith('.uk')) targetFile = 'uk.txt';

  if (targetFile) {
    fs.appendFileSync(
      path.join(__dirname, targetFile),
      JSON.stringify(record) + '\n'
    );
  }
});