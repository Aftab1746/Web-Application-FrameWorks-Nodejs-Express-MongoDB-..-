const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "MOCK_DATA.json");
const rawData = fs.readFileSync(dataPath, "utf8");
const records = JSON.parse(rawData);


const files = {
  A: "IP_Class_A.txt",
  B: "IP_Class_B.txt",
  C: "IP_Class_C.txt",
  D: "IP_Class_D.txt",
  E: "IP_Class_E.txt",
};


Object.values(files).forEach((file) => {
  const filePath = path.join(__dirname, file);
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, "");
});


function getIPClass(ip) {
  const firstOctet = parseInt(ip.split(".")[0]);
  if (firstOctet >= 1 && firstOctet <= 126) return "A";
  if (firstOctet >= 128 && firstOctet <= 191) return "B";
  if (firstOctet >= 192 && firstOctet <= 223) return "C";
  if (firstOctet >= 224 && firstOctet <= 239) return "D";
  if (firstOctet >= 240 && firstOctet <= 255) return "E";
  return "Unknown";
}

// Step 5: Classify and write records
records.forEach((record) => {
  const ipClass = getIPClass(record.ip_address);
  const targetFile = files[ipClass];

  if (targetFile) {
    fs.appendFileSync(
      path.join(__dirname, targetFile),
      JSON.stringify(record) + "\n"
    );
  }
});

console.log("IP Address classification complete!");
console.log(
  "Files created: IP_Class_A.txt, IP_Class_B.txt, IP_Class_C.txt, IP_Class_D.txt, IP_Class_E.txt"
);
